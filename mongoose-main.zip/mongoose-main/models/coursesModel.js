const { ObjectId } = require("mongodb");
const mongoose = require("mongoose");
const groups = require("./groupsModel");

const teachersSchema = mongoose.Schema(
  {
    _id: {
      type: ObjectId,
    },
    teacherName: {
      type: String,
      required: [true, "Please add the user name address"],
    },
    phoneNumber: {
      type: String,
    },
    groups: [{
        type: groupsSchema,
        ref:'groups'
    }]
  });

module.exports = mongoose.model("courses", coursesSchema, "courses");

