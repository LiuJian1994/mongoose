const { ObjectId } = require("mongodb");
const mongoose = require("mongoose");
const courses = require("./coursesModel");

const teachersSchema = mongoose.Schema(
  {
    _id: {
      type: ObjectId,
    },
    teacherName: {
      type: String,
      required: [true, "Please add the user name address"],
    },
    phoneNumber: {
      type: String,
    },
    course: [{
        type: groupsSchema,
        ref:'courses'
    }]
  });

module.exports = mongoose.model("teachers", teachersSchema, "teachers");

