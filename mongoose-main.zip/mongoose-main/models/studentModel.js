const { ObjectId } = require("mongodb");
const mongoose = require("mongoose");
const groups = require("./groupsModel");

const studentsSchema = mongoose.Schema(
  {
    _id: {
      type: ObjectId,
    },
    studentID:{
      type: String,
      required: [true, "Please add the studentID"],
    },
    IDnumber:{
      type: String,
    },
    name: {
      type: String,
      required: [true, "Please add the name"],
    },
    gender:{
      type: String,
    },
    state: {
      type: String,
    },
    PhoneNumber: {
      type: String,
    },
    group: {
      type: groupsSchema,
      ref:'groups'
    },
  },
);

module.exports = mongoose.model("students", studentsSchema, "students");
