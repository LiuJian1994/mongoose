const { ObjectId } = require("mongodb");

const mongoose = require("mongoose");
const courses = require("./coursesModel");

const groupsSchema = mongoose.Schema(
  {
    _id: {
      type: ObjectId,
    },
    groupName: {
      type: String,
    },
    subject: {
      type: String,
    },
    grade: {
        type: String,
    },
    courses:[{
      type: ObjectId,
      ref: 'courses'
    }]
  });

module.exports = mongoose.model("groups", teachersSchema, "groups");

